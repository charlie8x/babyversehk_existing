<?php
/**
 * Adds options to the customizer for Babystreet.
 */

defined( 'ABSPATH' ) || exit;

class Babystreet_Customizer {
	function __construct() {
		add_action( 'customize_register', array( $this, 'add_sections' ) );
	}

	/**
	 * Add settings to the customizer.
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	public function add_sections( $wp_customize ) {
		$wp_customize->add_panel( 'babystreet_plugin', array(
			'priority'       => 200,
			'capability'     => 'edit_theme_options',
			'theme_supports' => '',
			'title'          => esc_html__( 'Babystreet Options', 'babystreet-plugin' ),
		) );

		$this->add_social_share_section( $wp_customize );
	}

	/**
	 * Social share links section.
	 *
	 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
	 */
	public function add_social_share_section( $wp_customize ) {
		$wp_customize->add_section(
			'babystreet_social_share',
			array(
				'title'       => esc_html__( 'Social Share Links', 'babystreet-plugin' ),
				'description' => esc_html__( 'Configure globally the social networks share links. They can be overridden for each post, page or portfolio on the edit page.', 'babystreet-plugin' ),
				'priority'    => 10,
				'panel'       => 'babystreet_plugin',
			)
		);

		$wp_customize->add_setting(
			'babystreet_share_on_posts',
			array(
				'default'           => babystreet_default_share_on_posts(),
				'type'              => 'option',
				'capability'        => 'edit_theme_options',
				'sanitize_callback' => array( $this, 'babystreet_bool_to_string' ),
				'sanitize_js_callback' => array( $this, 'babystreet_string_to_bool' )
			)
		);

		$wp_customize->add_control(
			'babystreet_share_on_posts_field',
			array(
				'label'    => esc_html__( 'Enable social share links on single post, page and portfolio.', 'babystreet-plugin' ),
				'section'  => 'babystreet_social_share',
				'settings' => 'babystreet_share_on_posts',
				'type'     => 'checkbox'
			)
		);

		if ( defined( 'BABYSTREET_PLUGIN_IS_WOOCOMMERCE' ) && BABYSTREET_PLUGIN_IS_WOOCOMMERCE ) {
			$wp_customize->add_setting(
				'babystreet_share_on_products',
				array(
					'default'           => babystreet_default_share_on_products(),
					'type'              => 'option',
					'capability'        => 'edit_theme_options',
					'sanitize_callback' => array( $this, 'babystreet_bool_to_string' ),
					'sanitize_js_callback' => array( $this, 'babystreet_string_to_bool' )
				)
			);

			$wp_customize->add_control(
				'babystreet_share_on_products_field',
				array(
					'label'    => esc_html__( 'Enable social share links on single product pages.', 'babystreet-plugin' ),
					'section'  => 'babystreet_social_share',
					'settings' => 'babystreet_share_on_products',
					'type'     => 'checkbox'
				)
			);
		}
	}

	public function babystreet_bool_to_string( $bool ) {
		if ( ! is_bool( $bool ) ) {
			$bool = $this->babystreet_string_to_bool($bool);
		}
		return true === $bool ? 'yes' : 'no';
	}

	public function babystreet_string_to_bool( $string ) {
		return is_bool( $string ) ? $string : ( 'yes' === $string || 1 === $string || 'true' === $string || '1' === $string );
	}
}

new Babystreet_Customizer();