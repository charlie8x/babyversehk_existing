<?php
wp_enqueue_script('jquery-form');

//fields translatable strings
$babystreet_fields_strings = array();
$babystreet_fields_strings['name'] = esc_html__('Name', 'babystreet-plugin');
$babystreet_fields_strings['email'] = esc_html__('E-Mail Address', 'babystreet-plugin');
$babystreet_fields_strings['phone'] = esc_html__('Phone', 'babystreet-plugin');
$babystreet_fields_strings['address'] = esc_html__('Street Address', 'babystreet-plugin');
$babystreet_fields_strings['subject'] = esc_html__('Subject', 'babystreet-plugin');

//response messages
$babystreet_missing_content = esc_html__('Please enter %s.', 'babystreet-plugin');
$babystreet_missing_message = esc_html__('Please enter a message.', 'babystreet-plugin');
$babystreet_captcha_message = esc_html__('Calculation result was not correct.', 'babystreet-plugin');
$babystreet_email_invalid = esc_html__('Email Address Invalid.', 'babystreet-plugin');
$babystreet_message_unsent = esc_html__('Message was not sent. Try Again.', 'babystreet-plugin');
$babystreet_message_sent = esc_html__('Thanks! Your message has been sent.', 'babystreet-plugin');

//user posted variables
$babystreet_subject = array_key_exists('babystreet_subject', $_POST) ? $_POST['babystreet_subject'] : '';
$babystreet_email = array_key_exists('babystreet_email', $_POST) ? $_POST['babystreet_email'] : '';
$babystreet_name = array_key_exists('babystreet_name', $_POST) ? $_POST['babystreet_name'] : '';
$babystreet_phone = array_key_exists('babystreet_phone', $_POST) ? $_POST['babystreet_phone'] : '';
$babystreet_address = array_key_exists('babystreet_address', $_POST) ? $_POST['babystreet_address'] : '';
$babystreet_message = array_key_exists('babystreet_enquiry', $_POST) ? $_POST['babystreet_enquiry'] : '';
$babystreet_captcha_rand = array_key_exists('babystreet_contact_submitted', $_POST) ? $_POST['babystreet_contact_submitted'] : '';
$babystreet_captcha_answer = array_key_exists('babystreet_captcha_answer', $_POST) ? $_POST['babystreet_captcha_answer'] : '';
// shortcode params
if (!isset($babystreet_shortcode_params_for_tpl)) {
	$babystreet_shortcode_params_for_tpl = array_key_exists('shortcode_params_for_tpl', $_POST) ? stripcslashes($_POST['shortcode_params_for_tpl']) : '';
}

if ($babystreet_shortcode_params_for_tpl) {
	$babystreet_shortcode_params_array = json_decode($babystreet_shortcode_params_for_tpl, true);
	if ($babystreet_shortcode_params_array) {
		extract($babystreet_shortcode_params_array);
	}
}

$babystreet_headers = '';
$babystreet_contactform_response = '';
$babystreet_rand_captcha = '';

/* Get choosen fields from Options */
$babystreet_contacts_fields = array();

/* if is from shortcode */
if (isset($babystreet_contact_form_fields)) {

	if(is_string($babystreet_contact_form_fields)) {
		$babystreet_contact_form_fields_arr = explode( ',', $babystreet_contact_form_fields );
	} elseif (is_array($babystreet_contact_form_fields)) {
		$babystreet_contact_form_fields_arr = $babystreet_contact_form_fields;
	} else {
	    $babystreet_contact_form_fields_arr = array();
    }

	foreach($babystreet_contact_form_fields_arr as $babystreet_field)    {
		$babystreet_contacts_fields[$babystreet_field] = true;
	}
}

$babystreet_has_error = false;
$babystreet_name_error = $babystreet_email_error = $babystreet_phone_error = $babystreet_address_error = $babystreet_subject_error = $babystreet_message_error = $babystreet_captcha_error = false;

if (isset($_POST['babystreet_contact_submitted'])) {

	/* Validate Email address */
	if ($babystreet_email && $babystreet_contacts_fields['email'] && !filter_var($babystreet_email, FILTER_VALIDATE_EMAIL)) {
		$babystreet_has_error = true;
		$babystreet_email_error = babystreet_contact_form_generate_response("error", $babystreet_email_invalid);
	} else {
		$babystreet_headers = 'From: ' . sanitize_email($babystreet_email) . "\r\n" . 'Reply-To: ' . sanitize_email($babystreet_email) . "\r\n";
	}

	/* Check if all fields are filled */
	foreach ($babystreet_contacts_fields as $babystreet_fieldname => $babystreet_is_enabled) {
		if ($babystreet_is_enabled && !${'babystreet_' . $babystreet_fieldname}) {
			$babystreet_has_error = true;
			${'babystreet_' . $babystreet_fieldname . '_error'} = babystreet_contact_form_generate_response("error", sprintf($babystreet_missing_content, $babystreet_fields_strings[$babystreet_fieldname]));
		}
	}

	/* Check for a message */
	if (!trim($babystreet_message)) {
		$babystreet_has_error = true;
		$babystreet_message_error = babystreet_contact_form_generate_response("error", $babystreet_missing_message);
	}

	/* captcha validation */
	if ($babystreet_simple_captcha) {
		if ((int) $babystreet_captcha_rand + 1 !== (int) $babystreet_captcha_answer) {
			$babystreet_has_error = true;
			$babystreet_captcha_error = babystreet_contact_form_generate_response("error", $babystreet_captcha_message);
		}
	}

	if (!$babystreet_has_error) {
		$babystreet_sent = wp_mail(sanitize_email($babystreet_contact_mail_to), ($babystreet_subject ? sanitize_text_field($babystreet_subject) : sprintf(esc_html__('Someone sent a message from %s', 'babystreet-plugin'), sanitize_text_field(get_bloginfo('name')))), ($babystreet_name ? "Name: " . sanitize_text_field($babystreet_name) : "") . "\r\n" . ($babystreet_email ? "E-Mail Address: " . sanitize_text_field($babystreet_email) . "\r\n" : "") . ($babystreet_phone ? "Phone: " . sanitize_text_field($babystreet_phone) . "\r\n" : "") . ($babystreet_address ? "Street Address: " . sanitize_text_field($babystreet_address) . "\r\n" : "") . "\r\n" . wp_kses_post($babystreet_message), $babystreet_headers);
		if ($babystreet_sent) {
			$babystreet_contactform_response = babystreet_contact_form_generate_response("success", $babystreet_message_sent); //message sent!
			//clear values
			$babystreet_subject = $babystreet_email = $babystreet_name = $babystreet_phone = $babystreet_address = $babystreet_message = '';
		} else {
			$babystreet_contactform_response = babystreet_contact_form_generate_response("error", $babystreet_message_unsent); //message wasn't sent
		}
	}
}

$babystreet_contact_title = isset($babystreet_title) ? $babystreet_title : esc_html__('Send us a message', 'babystreet-plugin');
?>
<?php if ($babystreet_contact_title): ?>
	<h2 class="contact-form-title"><?php echo esc_html($babystreet_contact_title) ?></h2>
<?php endif; ?>
<form action="<?php echo esc_url(admin_url('admin-ajax.php')) ?>" method="post" class="contact-form">
	<?php if (isset($babystreet_contacts_fields['name'])): ?>
		<div class="content babystreet_name"> <span><?php esc_html_e('Your Name', 'babystreet-plugin'); ?>:</span>
			<input type="text" value="<?php echo esc_attr($babystreet_name); ?>" name="babystreet_name" />
			<?php if ($babystreet_name_error) echo wp_kses_post($babystreet_name_error); ?>
		</div>

	<?php endif; ?>
	<?php if (isset($babystreet_contacts_fields['email'])): ?>
		<div class="content babystreet_email"> <span><?php esc_html_e('E-Mail Address', 'babystreet-plugin'); ?>:</span>
			<input type="text" value="<?php echo esc_attr($babystreet_email); ?>" name="babystreet_email" />
			<?php if ($babystreet_email_error) echo wp_kses_post($babystreet_email_error); ?>
		</div>
	<?php endif; ?>
	<?php if (isset($babystreet_contacts_fields['phone'])): ?>
		<div class="content babystreet_phone"> <span><?php esc_html_e('Phone', 'babystreet-plugin'); ?>:</span>
			<input type="text" value="<?php echo esc_attr($babystreet_phone); ?>" name="babystreet_phone" />
			<?php if ($babystreet_phone_error) echo wp_kses_post($babystreet_phone_error); ?>
		</div>
	<?php endif; ?>
	<?php if (isset($babystreet_contacts_fields['address'])): ?>
		<div class="content babystreet_address"> <span><?php esc_html_e('Street Address', 'babystreet-plugin'); ?>:</span>
			<input type="text" value="<?php echo esc_attr($babystreet_address); ?>" name="babystreet_address" />
			<?php if ($babystreet_address_error) echo wp_kses_post($babystreet_address_error); ?>
		</div>
	<?php endif; ?>
	<?php if (isset($babystreet_contacts_fields['subject'])): ?>
		<div class="content babystreet_subject"> <span><?php esc_html_e('Subject', 'babystreet-plugin'); ?>:</span>
			<input type="text" value="<?php echo esc_attr($babystreet_subject); ?>" name="babystreet_subject" />
			<?php if ($babystreet_subject_error) echo wp_kses_post($babystreet_subject_error); ?>
		</div>
	<?php endif; ?>
	<div class="content babystreet_enquiry"> <span><?php esc_html_e('Message Text', 'babystreet-plugin'); ?>:</span>
		<textarea style="width: 99%;" rows="10" cols="40" name="babystreet_enquiry"><?php echo esc_textarea($babystreet_message); ?></textarea>
		<?php if ($babystreet_message_error) echo wp_kses_post($babystreet_message_error); ?>
	</div>
	<?php if ($babystreet_simple_captcha): ?>
		<?php $babystreet_rand_captcha = mt_rand(0, 8); ?>
		<div class="content babystreet_form_test">
			<?php echo esc_html__("Prove you're a human", 'babystreet-plugin') ?>: <span class=constant>1</span> + <span class=random><?php echo esc_html($babystreet_rand_captcha) ?></span> = ? <input type="text" value="" name="babystreet_captcha_answer" />
		</div>
		<?php if ($babystreet_captcha_error) echo wp_kses_post($babystreet_captcha_error); ?>
	<?php endif; ?>
	<?php echo wp_kses_post($babystreet_contactform_response); ?>
	<div class="buttons">
		<input type="hidden" name="babystreet_contact_submitted" value="<?php echo esc_attr($babystreet_rand_captcha) ?>">
		<input type="hidden" name="shortcode_params_for_tpl" value="<?php echo esc_attr($babystreet_shortcode_params_for_tpl) ?>">
		<div class="left"><input class="button button-orange" value="<?php esc_html_e('Send message', 'babystreet-plugin') ?>" type="submit"></div>
	</div>
</form>
