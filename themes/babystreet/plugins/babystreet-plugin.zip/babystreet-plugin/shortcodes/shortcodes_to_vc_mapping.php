<?php
/**
 * Map all Babystreet shortcodes to VC
 */
if (!function_exists('babystreet_integrateWithVC')) {

	function babystreet_integrateWithVC() {

		$current_user_email = '';
		if (is_user_logged_in()) {
			$the_logged_user = wp_get_current_user();
			if ($the_logged_user instanceof WP_User) {
				$current_user_email = $the_logged_user->user_email;
			}
		}

		$althem_icon = plugins_url('assets/image/VC_logo_alth.png', dirname(__FILE__));
		$latest_projects_columns_values = array(1, 2, 3, 4, 5, 6);
		$banner_alignment_styles = array(
			esc_html__('Center-Center', 'babystreet-plugin') => 'banner-center-center',
			esc_html__('Top-Left', 'babystreet-plugin') => 'banner-top-left',
			esc_html__('Top-Center', 'babystreet-plugin') => 'banner-top-center',
			esc_html__('Top-Right', 'babystreet-plugin') => 'banner-top-right',
			esc_html__('Center-Left', 'babystreet-plugin') => 'banner-center-left',
			esc_html__('Center-Right', 'babystreet-plugin') => 'banner-center-right',
			esc_html__('Bottom-Left', 'babystreet-plugin') => 'banner-bottom-left',
			esc_html__('Bottom-Center', 'babystreet-plugin') => 'banner-bottom-center',
			esc_html__('Bottom-Right', 'babystreet-plugin') => 'banner-bottom-right',
		);

		// Map babystreet_counter
		if (defined('WPB_VC_VERSION')) {
			require_once vc_path_dir('CONFIG_DIR', 'content/vc-icon-element.php');

			$icon_params = vc_map_integrate_shortcode(vc_icon_element_params(), 'i_', '', array(
				// we need only type, icon_fontawesome, icon_.., NOT etc
				'include_only_regex' => '/^(type|icon_\w*)/',
			), array(
				'element' => 'add_icon',
				'value' => 'true',
			));

			$params = array_merge(array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Text before counter', 'babystreet-plugin'),
					'param_name' => 'txt_before_counter',
					'value' => '',
					'description' => esc_html__('Enter text to be shown before counter.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Counting number', 'babystreet-plugin'),
					'param_name' => 'count_number',
					'value' => '10',
					'description' => esc_html__('Enter the number to count to.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Text after counter', 'babystreet-plugin'),
					'param_name' => 'txt_after_counter',
					'value' => '',
					'description' => esc_html__('Enter text to be shown after counter.', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'add_icon',
					'heading' => esc_html__('Add icon?', 'babystreet-plugin'),
					'description' => esc_html__('Add icon to the counter.', 'babystreet-plugin'),
				)), $icon_params, array(
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Icon color', 'babystreet-plugin'),
					'param_name' => 'i_custom_color',
					'value' => '',
					'description' => esc_html__('Select icon color.', 'babystreet-plugin'),
					'dependency' => array(
						'element' => 'add_icon',
						'value' => 'true'
					)
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'counter_style',
					'value' => array(
						'H1' => 'h1',
						'H2' => 'h2',
						'H3' => 'h3',
						'H4' => 'h4',
						'H5' => 'h5',
						'H6' => 'h6',
						'Paragraph' => 'paragraph'
					),
					'std' => 'h4',
					'heading' => esc_html__('Counter style', 'babystreet-plugin'),
					'description' => esc_html__('Select counter style.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'counter_alignment',
					'value' => array(
						esc_html__('Left', 'babystreet-plugin') => 'babystreet-counter-left',
						esc_html__('Centered', 'babystreet-plugin') => 'babystreet-counter-centered',
						esc_html__('Right', 'babystreet-plugin') => 'babystreet-counter-right',
					),
					'std' => 'babystreet-counter-left',
					'heading' => esc_html__('Counter alignment', 'babystreet-plugin'),
					'description' => esc_html__('Select counter alignment style.', 'babystreet-plugin'),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Text color', 'babystreet-plugin'),
					'param_name' => 'text_color',
					'value' => '',
					'description' => esc_html__('Choose color for the counter text.', 'babystreet-plugin'),
				),
			));

			// Remove Icon library admin label
			unset($params[4]['admin_label']);

			vc_map(array(
					'name' => esc_html__('Counter', 'babystreet-plugin'),
					'base' => 'babystreet_counter',
					'icon' => $althem_icon,
					'description' => esc_html__('Configure counter', 'babystreet-plugin'),
					'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
					'params' => $params,
				)
			);
		}

		// Map babystreet_typed
		vc_map(array(
				'name' => esc_html__('Typed', 'babystreet-plugin'),
				'base' => 'babystreet_typed',
				'icon' => $althem_icon,
				'description' => esc_html__('Animated typing', 'babystreet-plugin'),
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Text before typing rotator', 'babystreet-plugin'),
						'param_name' => 'txt_before_typed',
						'value' => '',
						'description' => esc_html__('Enter text to be shown before typing rotator.', 'babystreet-plugin'),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Rotating strings', 'babystreet-plugin'),
						'param_name' => 'rotating_strings',
						'value' => 'One,Two,Tree',
						'description' => esc_html__('Enter strings to be rotated, separated by comma, (e.g. One,Two,Tree). Please only use letters and numbers. No special characters. If it’s necessary to use special characters, please use HTML Entities instead (e.g. “&amp;amp;” instead of “&”)', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Text after typing rotator', 'babystreet-plugin'),
						'param_name' => 'txt_after_typed',
						'value' => '',
						'description' => esc_html__('Enter text to be shown after typing rotator.', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'param_name' => 'typed_style',
						'value' => array(
							'H1' => 'h1',
							'H2' => 'h2',
							'H3' => 'h3',
							'H4' => 'h4',
							'H5' => 'h5',
							'H6' => 'h6',
							'Paragraph' => 'paragraph'
						),
						'std' => 'h4',
						'heading' => esc_html__('Typed style', 'babystreet-plugin'),
						'description' => esc_html__('Select style.', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'param_name' => 'typed_alignment',
						'value' => array(
							esc_html__('Left', 'babystreet-plugin') => 'babystreet-typed-left',
							esc_html__('Centered', 'babystreet-plugin') => 'babystreet-typed-centered',
							esc_html__('Right', 'babystreet-plugin') => 'babystreet-typed-right',
						),
						'std' => 'babystreet-typed-left',
						'heading' => esc_html__('Alignment', 'babystreet-plugin'),
						'description' => esc_html__('Select alignment style.', 'babystreet-plugin'),
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Static text color', 'babystreet-plugin'),
						'param_name' => 'static_text_color',
						'value' => '',
						'description' => esc_html__('Choose color for the static text.', 'babystreet-plugin'),
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Typed text color', 'babystreet-plugin'),
						'param_name' => 'typed_text_color',
						'value' => '',
						'description' => esc_html__('Choose color for the typed text.', 'babystreet-plugin'),
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__('Loop', 'babystreet-plugin'),
						'param_name' => 'loop',
						'value' => array(esc_html__('Start from beginning after the last string.', 'babystreet-plugin') => 'yes'),
						'std' => 'yes'
					),
					array(
						'type' => 'css_editor',
						'heading' => esc_html__('CSS box', 'babystreet-plugin'),
						'param_name' => 'css',
						'group' => esc_html__('Design Options', 'babystreet-plugin'),
					),
				),)
		);

		// Map babystreet_content_slider shortcode
		vc_map(array(
			'name' => esc_html__('Content Slider', 'babystreet-plugin'),
			'base' => 'babystreet_content_slider',
			'icon' => $althem_icon,
			'is_container' => true,
			'show_settings_on_create' => false,
			'as_parent' => array(
				'only' => 'vc_tta_section',
			),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'description' => esc_html__('Slide any content', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'param_name' => 'title',
					'heading' => esc_html__('Widget title', 'babystreet-plugin'),
					'description' => esc_html__('Enter text used as widget title (Note: located above content element).', 'babystreet-plugin'),
				),
				array(
					'type' => 'hidden',
					'param_name' => 'no_fill_content_area',
					'std' => true,
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'autoplay',
					'value' => array(
						esc_html__('None', 'babystreet-plugin') => 'none',
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
						'10' => '10',
						'20' => '20',
						'30' => '30',
						'40' => '40',
						'50' => '50',
						'60' => '60',
					),
					'std' => 'none',
					'heading' => esc_html__('Autoplay', 'babystreet-plugin'),
					'description' => esc_html__('Select auto rotate for pageable in seconds (Note: disabled by default).', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Full-Height slider', 'babystreet-plugin'),
					'param_name' => 'full_height',
					'value' => array(esc_html__('Display slider in full height', 'babystreet-plugin') => 'yes'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Prev / Next navigation', 'babystreet-plugin'),
					'param_name' => 'navigation',
					'value' => array(esc_html__('Enable Prev / Next navigation', 'babystreet-plugin') => 'yes'),
					'std' => 'yes'
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'navigation_color',
					'value' => array(
						esc_html__('Light', 'babystreet-plugin') => 'babystreet_content_slider_light_nav',
						esc_html__('Dark', 'babystreet-plugin') => 'babystreet_content_slider_dark_nav',
					),
					'std' => 'babystreet_content_slider_light_nav',
					'heading' => esc_html__('Navigation Color', 'babystreet-plugin'),
					'description' => esc_html__('Choose light or dark navigation, depending on the background.', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Pause On Hover', 'babystreet-plugin'),
					'param_name' => 'pause_on_hover',
					'value' => array(esc_html__('Should the slider pause on hover', 'babystreet-plugin') => 'yes'),
					'std' => 'yes'
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Pagination', 'babystreet-plugin'),
					'param_name' => 'pagination',
					'value' => array(esc_html__('Enable pagination', 'babystreet-plugin') => 'yes'),
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'pagination_type',
					'value' => array(
						esc_html__('Bullets', 'babystreet-plugin') => 'babystreet-pagination-bullets',
						esc_html__('Numbers', 'babystreet-plugin') => 'babystreet-pagination-numbers'
					),
					'std' => 'babystreet-pagination-bullets',
					'heading' => esc_html__('Pagination Type', 'babystreet-plugin'),
					'description' => esc_html__('Select pagination type.', 'babystreet-plugin'),
					'dependency' => array(
						'element' => 'pagination',
						'value' => 'yes'
					)
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'transition',
					'value' => array(
						esc_html__('Fade', 'babystreet-plugin') => 'fade',
						esc_html__('Slide', 'babystreet-plugin') => 'slide',
						esc_html__('Slide-Flip', 'babystreet-plugin') => 'slide-flip',
					),
					'std' => 'fade',
					'heading' => esc_html__('Transition', 'babystreet-plugin'),
					'description' => esc_html__('Select transition effect.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Extra class name', 'babystreet-plugin'),
					'param_name' => 'el_class',
					'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then babystreet to it in your css file.', 'babystreet-plugin') . '<br/><br/>' . esc_html__('NOTE: If video backgrounds are used in slides content, the loop slides option would be automatically disabled for compatibility reasons.', 'babystreet-plugin'),
				),
				array(
					'type' => 'css_editor',
					'heading' => esc_html__('CSS box', 'babystreet-plugin'),
					'param_name' => 'css',
					'group' => esc_html__('Design Options', 'babystreet-plugin'),
				),
			),
			'js_view' => 'VcBackendTtaPageableView',
			'custom_markup' => '
<div class="vc_tta-container vc_tta-o-non-responsive" data-vc-action="collapse">
	<div class="vc_general vc_tta vc_tta-tabs vc_tta-pageable vc_tta-color-backend-tabs-white vc_tta-style-flat vc_tta-shape-rounded vc_tta-spacing-1 vc_tta-tabs-position-top vc_tta-controls-align-left">
		<div class="vc_tta-tabs-container">'
			                   . '<ul class="vc_tta-tabs-list">'
			                   . '<li class="vc_tta-tab" data-vc-tab data-vc-target-model-id="{{ model_id }}" data-element_type="vc_tta_section"><a href="javascript:;" data-vc-tabs data-vc-container=".vc_tta" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-target-model-id="{{ model_id }}"><span class="vc_tta-title-text">{{ section_title }}</span></a></li>'
			                   . '</ul>
		</div>
		<div class="vc_tta-panels vc_clearfix {{container-class}}">
		  {{ content }}
		</div>
	</div>
</div>',
			'default_content' => '
[vc_tta_section title="' . sprintf('%s %d', esc_html__('Section', 'babystreet-plugin'), 1) . '"][/vc_tta_section]
[vc_tta_section title="' . sprintf('%s %d', esc_html__('Section', 'babystreet-plugin'), 2) . '"][/vc_tta_section]
	',
			'admin_enqueue_js' => array(
				vc_asset_url('lib/vc_tabs/vc-tabs.min.js'),
			),
		));

// Map babystreetblogposts shortcode
		vc_map(array(
			'name' => esc_html__('Blog Posts', 'babystreet-plugin'),
			'base' => 'babystreetblogposts',
			'icon' => $althem_icon,
			'description' => esc_html__('Output Blog posts with customizable Blog style', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Blog style', 'babystreet-plugin'),
					'param_name' => 'blog_style',
					'value' => array(
						esc_html__('Standard', 'babystreet-plugin') => '',
						esc_html__('Masonry Tiles', 'babystreet-plugin') => 'babystreet_blog_masonry',
						esc_html__('Mozaic', 'babystreet-plugin') => 'babystreet_blog_masonry babystreet-mozaic',
					),
					'description' => esc_html__('Choose how the posts will appear.', 'babystreet-plugin')
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Sorting direction', 'babystreet-plugin'),
					'param_name' => 'date_sort',
					'value' => array(
						esc_html__('WordPress Default', 'babystreet-plugin') => 'default',
						esc_html__('Ascending', 'babystreet-plugin') => 'ASC',
						esc_html__('Descending', 'babystreet-plugin') => 'DESC'
					),
					'description' => esc_html__('Choose the date sorting direction.', 'babystreet-plugin')
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Posts per page', 'babystreet-plugin'),
					'param_name' => 'number_of_posts',
					'value' => '',
					'description' => esc_html__('Enter the number of posts displayed per page. Leave blank for default.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Offset', 'babystreet-plugin'),
					'param_name' => 'offset',
					'value' => '',
					'description' => esc_html__('Set number of posts to be skipped.', 'babystreet-plugin'),
				)
			)
		));

		// Map babystreet_latest_posts shortcode
		// Define filters to be able to use the Taxonomies search autocomplete field
		add_filter('vc_autocomplete_babystreet_latest_posts_taxonomies_callback', 'babystreet_latest_posts_category_field_search', 10, 1);
		add_filter('vc_autocomplete_babystreet_latest_posts_taxonomies_render', 'vc_autocomplete_taxonomies_field_render', 10, 1);
		vc_map(array(
			'name' => esc_html__('Latest Posts', 'babystreet-plugin'),
			'base' => 'babystreet_latest_posts',
			'icon' => $althem_icon,
			'description' => esc_html__('Show Latest Posts', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Layout', 'babystreet-plugin'),
					'value' => array(
						esc_html__('Grid', 'babystreet-plugin') => 'grid',
						esc_html__('Carousel', 'babystreet-plugin') => 'carousel',
					),
					'param_name' => 'layout',
					'admin_label' => true
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Columns', 'babystreet-plugin'),
					'value' => $latest_projects_columns_values,
					'param_name' => 'columns',
					'description' => esc_html__('Number of columns', 'babystreet-plugin'),
					'admin_label' => true,
					'dependency' => array(
						'element' => 'layout',
						'value' => array('grid', 'carousel')
					)
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__('Filter By Category', 'babystreet-plugin'),
					'param_name' => 'taxonomies',
					'settings' => array(
						'multiple' => true,
						'min_length' => 1,
						'groups' => false,
						// In UI show results grouped by groups, default false
						'unique_values' => true,
						// In UI show results except selected. NB! You should manually check values in backend, default false
						'display_inline' => true,
						// In UI show results inline view, default false (each value in own line)
						'delay' => 500,
						// delay for search. default 500
						'auto_focus' => true,
						// auto focus input, default true
					),
					'param_holder_class' => 'vc_not-for-custom',
					'description' => esc_html__('Enter category names.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Number of posts', 'babystreet-plugin'),
					'param_name' => 'number_of_posts',
					'value' => '4',
					'description' => esc_html__('Enter the number of posts to be displayed.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Offset', 'babystreet-plugin'),
					'param_name' => 'offset',
					'value' => '',
					'description' => esc_html__('Set number of posts to be skipped.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Sorting direction', 'babystreet-plugin'),
					'param_name' => 'date_sort',
					'value' => array(
						esc_html__('WordPress Default', 'babystreet-plugin') => 'default',
						esc_html__('Ascending', 'babystreet-plugin') => 'ASC',
						esc_html__('Descending', 'babystreet-plugin') => 'DESC'
					),
					'description' => esc_html__('Choose the date sorting direction.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'css_editor',
					'heading' => esc_html__('CSS box', 'babystreet-plugin'),
					'param_name' => 'css',
					'group' => esc_html__('Design Options', 'babystreet-plugin'),
				),
			)
		));

		// Map babystreet_banner shortcode
		vc_map(array(
			'name' => esc_html__('Banner', 'babystreet-plugin'),
			'base' => 'babystreet_banner',
			'icon' => $althem_icon,
			'description' => esc_html__('Output configurable banner', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Alignment', 'babystreet-plugin'),
					'value' => $banner_alignment_styles,
					'param_name' => 'alignment',
					'description' => esc_html__('Choose alginment style for the banner.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Icon library', 'babystreet-plugin'),
					'value' => array(
						esc_html__('Font Awesome 5', 'babystreet-plugin') => 'fontawesome',
						esc_html__('Open Iconic', 'babystreet-plugin') => 'openiconic',
						esc_html__('Typicons', 'babystreet-plugin') => 'typicons',
						esc_html__('Entypo', 'babystreet-plugin') => 'entypo',
						esc_html__('Linecons', 'babystreet-plugin') => 'linecons',
						esc_html__('Elegant Icons Font', 'babystreet-plugin') => 'etline',
						esc_html__('Doodles Font', 'babystreet-plugin') => 'flaticon',
					),
					'admin_label' => true,
					'param_name' => 'type',
					'description' => esc_html__('Select icon library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_fontawesome',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true, // default true, display an "EMPTY" icon?
						'type' => 'fontawesome',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_openiconic',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true, // default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'openiconic',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_typicons',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true, // default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'typicons',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_entypo',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true, // default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_linecons',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true, // default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'linecons',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_etline',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true,
						'type' => 'etline',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'etline',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_flaticon',
					'value' => '', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => true,
						'type' => 'flaticon',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'flaticon',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Pre-Title', 'babystreet-plugin'),
					'param_name' => 'pre_title',
					'value' => '',
					'description' => esc_html__('Enter the banner pre-title.', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Special Pre-Title Font', 'babystreet-plugin'),
					'param_name' => 'pre_title_use_special_font',
					'description' => esc_html__('Recommended to be used only with short texts (5 to 6 characters).', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Main Title', 'babystreet-plugin'),
					'param_name' => 'title',
					'value' => '',
					'description' => esc_html__('Enter the banner main title.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Main Title Font Size', 'babystreet-plugin'),
					'param_name' => 'title_size',
					'value' => array(
						esc_html__('Default', 'babystreet-plugin') => '',
						esc_html__('Big', 'babystreet-plugin') => 'babystreet_banner_big',
					),
					'description' => esc_html__('Choose predefined main title font size.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Sub-Title', 'babystreet-plugin'),
					'param_name' => 'subtitle',
					'value' => '',
					'description' => esc_html__('Enter Sub-Title.', 'babystreet-plugin'),
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__('Image', 'babystreet-plugin'),
					'param_name' => 'image_id',
					'value' => '',
					'description' => esc_html__('Choose image for the banner. (Actual size will be used)', 'babystreet-plugin')
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Link', 'babystreet-plugin'),
					'param_name' => 'link',
					'value' => '',
					'description' => esc_html__('Enter the URL where the banner will lead to.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Open in', 'babystreet-plugin'),
					'value' => array(
						esc_html__('New window', 'babystreet-plugin') => '_blank',
						esc_html__('Same window', 'babystreet-plugin') => '_self',
					),
					'param_name' => 'link_target',
					'description' => esc_html__('Open link in new window or current.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Button Text', 'babystreet-plugin'),
					'param_name' => 'button_text',
					'value' => '',
					'description' => esc_html__('Enter text for the button.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Color Scheme', 'babystreet-plugin'),
					'param_name' => 'color_scheme',
					'value' => array(
						esc_html__('Light', 'babystreet-plugin') => '',
						esc_html__('Dark', 'babystreet-plugin') => 'babystreet-banner-dark',
					),
					'description' => esc_html__('Choose the color scheme.', 'babystreet-plugin')
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Appear Animation', 'babystreet-plugin'),
					'param_name' => 'appear_animation',
					'value' => array(
						esc_html__('none', 'babystreet-plugin') => '',
						esc_html__('From Left', 'babystreet-plugin') => 'babystreet-from-left',
						esc_html__('From Right', 'babystreet-plugin') => 'babystreet-from-right',
						esc_html__('From Bottom', 'babystreet-plugin') => 'babystreet-from-bottom',
						esc_html__('Fade', 'babystreet-plugin') => 'babystreet-fade'
					),
					'description' => esc_html__('Choose how the element will appear.', 'babystreet-plugin')
				),
				array(
					'type' => 'css_editor',
					'heading' => esc_html__('CSS box', 'babystreet-plugin'),
					'param_name' => 'css',
					'group' => esc_html__('Design Options', 'babystreet-plugin'),
				),
			),
			'js_view' => 'VcIconElementView_Backend',
		));

		// Map babystreet_cloudzoom_gallery shortcode
		vc_map(array(
			'name' => esc_html__('CloudZoom gallery', 'babystreet-plugin'),
			'base' => 'babystreet_cloudzoom_gallery',
			'icon' => $althem_icon,
			'description' => esc_html__('Output CloudZoom gallery', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'attach_images',
					'heading' => esc_html__('Images', 'babystreet-plugin'),
					'param_name' => 'images',
					'value' => '',
					'description' => esc_html__('Choose images for the gallery.', 'babystreet-plugin')
				)
			)
		));

		// Define filters to be able to use the Taxonomies search autocomplete field
		add_filter('vc_autocomplete_babystreet_latest_projects_taxonomies_callback', 'babystreet_portfolio_category_field_search', 10, 1);
		add_filter('vc_autocomplete_babystreet_latest_projects_taxonomies_render', 'vc_autocomplete_taxonomies_field_render', 10, 1);

		// Map babystreet_latest_projects shortcode
		vc_map(array(
			'name' => esc_html__('Projects', 'babystreet-plugin'),
			'base' => 'babystreet_latest_projects',
			'icon' => $althem_icon,
			'description' => esc_html__('Customisable Projects List', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('View Style', 'babystreet-plugin'),
					'value' => array(
						esc_html__('Grid View', 'babystreet-plugin') => 'grid',
						esc_html__('Carousel', 'babystreet-plugin') => 'carousel'
					),
					'param_name' => 'display_style',
					'description' => esc_html__('Choose view', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Columns', 'babystreet-plugin'),
					'value' => $latest_projects_columns_values,
					'param_name' => 'columns',
					'description' => esc_html__('Number of columns', 'babystreet-plugin'),
					'dependency' => array(
						'element' => 'display_style',
						'value' => array('grid', 'carousel')
					),
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__('Filter By Category', 'babystreet-plugin'),
					'param_name' => 'taxonomies',
					'settings' => array(
						'multiple' => true,
						'min_length' => 1,
						'groups' => false,
						// In UI show results grouped by groups, default false
						'unique_values' => true,
						// In UI show results except selected. NB! You should manually check values in backend, default false
						'display_inline' => true,
						// In UI show results inline view, default false (each value in own line)
						'delay' => 500,
						// delay for search. default 500
						'auto_focus' => true,
						// auto focus input, default true
					),
					'param_holder_class' => 'vc_not-for-custom',
					'description' => esc_html__('Enter project category names.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Portfolio Gaps', 'babystreet-plugin'),
					'value' => array(esc_html__('Show gap between projects', 'babystreet-plugin') => 'yes'),
					'param_name' => 'portfoio_cat_display',
					'dependency' => array(
						'element' => 'display_style',
						'value' => array('grid', 'carousel'),
					),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Lightbox', 'babystreet-plugin'),
					'param_name' => 'show_lightbox',
					'value' => array(esc_html__('Show link that opens the featured image in lightbox', 'babystreet-plugin') => 'yes'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Sortable', 'babystreet-plugin'),
					'param_name' => 'enable_sortable',
					'value' => array(esc_html__('Enable Sortable', 'babystreet-plugin') => 'yes'),
					'description' => esc_html__('Show the projects categories on top and show only projects from cpecific category, using sortable.', 'babystreet-plugin'),
					'admin_label' => true,
					'dependency' => array(
						'element' => 'display_style',
						'value' => array('grid'),
					),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Masonry', 'babystreet-plugin'),
					'param_name' => 'enable_masonry',
					'value' => array(esc_html__('Enable Masonry', 'babystreet-plugin') => 'yes'),
					'description' => esc_html__('Projects will be listed with soft crop of their featured images, keeping the original ratio.', 'babystreet-plugin'),
					'admin_label' => true,
					'dependency' => array(
						'element' => 'display_style',
						'value' => 'grid',
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Sorting direction', 'babystreet-plugin'),
					'param_name' => 'date_sort',
					'value' => array(
						esc_html__('Descending', 'babystreet-plugin') => 'DESC',
						esc_html__('Ascending', 'babystreet-plugin') => 'ASC'
					),
					'description' => esc_html__('Choose the date sorting direction.', 'babystreet-plugin')
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Number of Projects Listed', 'babystreet-plugin'),
					'param_name' => 'limit',
					'value' => '4',
					'description' => esc_html__('Enter the number of projects to be displayed. NOTE: If leaved empty and carousel option is not selected, porjects will be listed with infinite scroll/pagination', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Use Pagination', 'babystreet-plugin'),
					'param_name' => 'use_pagination',
					'value' => array(esc_html__('Use pagination instead of infinite scroll', 'babystreet-plugin') => 'yes'),
					'admin_label' => true,
					'dependency' => array(
						'element' => 'display_style',
						'value' => array('grid'),
					),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Use Load More Button', 'babystreet-plugin'),
					'param_name' => 'use_load_more',
					'value' => array(esc_html__('Use Load More Button to load the additional content', 'babystreet-plugin') => 'yes'),
					'admin_label' => true,
					'dependency' => array(
						'element' => 'use_pagination',
						'value_not_equal_to' => 'yes',
					),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Offset', 'babystreet-plugin'),
					'param_name' => 'offset',
					'value' => '',
					'description' => esc_html__('Set number of projects to be skipped.', 'babystreet-plugin'),
				),
				array(
					'type' => 'css_editor',
					'heading' => esc_html__('CSS box', 'babystreet-plugin'),
					'param_name' => 'css',
					'group' => esc_html__('Design Options', 'babystreet-plugin'),
				),
			)
		));

		// Map babystreet_icon_teaser shortcode
		vc_map(array(
			'name' => esc_html__('Icon Teaser', 'babystreet-plugin'),
			'base' => 'babystreet_icon_teaser',
			'icon' => $althem_icon,
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'description' => esc_html__('Icon teaser', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Title', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'title',
					'description' => esc_html__('Enter title', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Subtitle', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'subtitle',
					'description' => esc_html__('Enter subtitle', 'babystreet-plugin'),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Title/Subtitle Color', 'babystreet-plugin'),
					'param_name' => 'titles_color',
					'value' => '',
					'description' => esc_html__('Choose Title/Subtitle color.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Align', 'babystreet-plugin'),
					'value' => array(
						'Left' => 'teaser-left',
						'Right' => 'teaser-right'
					),
					'param_name' => 'align',
					'description' => esc_html__('Choose alignment', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Appear Animation', 'babystreet-plugin'),
					'param_name' => 'appear_animation',
					'value' => array(
						esc_html__('none', 'babystreet-plugin') => '',
						esc_html__('From Left', 'babystreet-plugin') => 'babystreet-from-left',
						esc_html__('From Right', 'babystreet-plugin') => 'babystreet-from-right',
						esc_html__('From Bottom', 'babystreet-plugin') => 'babystreet-from-bottom',
						esc_html__('Fade', 'babystreet-plugin') => 'babystreet-fade'
					),
					'description' => esc_html__('Choose how the element will appear.', 'babystreet-plugin')
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Icon library / Custom Image', 'babystreet-plugin'),
					'value' => array(
						esc_html__('Font Awesome 5', 'babystreet-plugin') => 'fontawesome',
						esc_html__('Elegant Icons Font', 'babystreet-plugin') => 'etline',
						esc_html__('Doodles Font', 'babystreet-plugin') => 'flaticon',
						esc_html__('Use Custom Image', 'babystreet-plugin') => 'custom_image',
					),
					'param_name' => 'type',
					'admin_label' => true,
					'description' => esc_html__('Select icon library or select image.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-adjust', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'fontawesome',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_etline',
					'value' => 'icon-mobile', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'etline',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'etline',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_flaticon',
					'value' => 'flaticon-3-standing-archives', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'flaticon',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'flaticon',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__('Image', 'babystreet-plugin'),
					'param_name' => 'icon_image_id',
					'value' => '',
					'description' => esc_html__('Choose image instead of icon. (60 x 60 size will be used)', 'babystreet-plugin'),
					'dependency' => array(
						'element' => 'type',
						'value' => 'custom_image',
					),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Icon color', 'babystreet-plugin'),
					'param_name' => 'color',
					'description' => esc_html__('Select icon color.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textarea_html',
					'holder' => 'div',
					'class' => '',
					'heading' => esc_html__('Text', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'content',
					'description' => esc_html__('Enter the text that will be used with the icon', 'babystreet-plugin'),
				),
			),
			'js_view' => 'VcIconElementView_Backend',
		));

		// Map babystreet_icon_box shortcode
		vc_map(array(
			'name' => esc_html__('Icon Box', 'babystreet-plugin'),
			'base' => 'babystreet_icon_box',
			'icon' => $althem_icon,
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'description' => esc_html__('Icon box', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Title', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'title',
					'description' => esc_html__('Enter title', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Subtitle', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'subtitle',
					'description' => esc_html__('Enter subtitle', 'babystreet-plugin'),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Title/Subtitle Color', 'babystreet-plugin'),
					'param_name' => 'titles_color',
					'value' => '',
					'description' => esc_html__('Choose Title/Subtitle color.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Icon Library / Custom Image', 'babystreet-plugin'),
					'value' => array(
						esc_html__('Font Awesome 5', 'babystreet-plugin') => 'fontawesome',
						esc_html__('Elegant Icons Font', 'babystreet-plugin') => 'etline',
						esc_html__('Flaticon Doodle', 'babystreet-plugin') => 'flaticon',
						esc_html__('Use Custom Image', 'babystreet-plugin') => 'custom_image',
					),
					'param_name' => 'type',
					'admin_label' => true,
					'description' => esc_html__('Select icon library or select image.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-adjust', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'fontawesome',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_etline',
					'value' => 'icon-mobile', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'etline',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'etline',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'iconpicker',
					'heading' => esc_html__('Icon', 'babystreet-plugin'),
					'param_name' => 'icon_flaticon',
					'value' => 'flaticon-3-standing-archives', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						'type' => 'flaticon',
						'iconsPerPage' => 100,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'flaticon',
					),
					'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__('Image', 'babystreet-plugin'),
					'param_name' => 'icon_image_id',
					'value' => '',
					'description' => esc_html__('Choose image instead of icon. (60 x 60 size will be used)', 'babystreet-plugin'),
					'dependency' => array(
						'element' => 'type',
						'value' => 'custom_image',
					),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Icon color', 'babystreet-plugin'),
					'param_name' => 'color',
					'description' => esc_html__('Select icon color.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Alignment', 'babystreet-plugin'),
					'param_name' => 'alignment',
					'value' => array(
						esc_html__('Center', 'babystreet-plugin') => '',
						esc_html__('Left', 'babystreet-plugin') => 'babystreet-icon-box-left',
						esc_html__('Right', 'babystreet-plugin') => 'babystreet-icon-box-right'
					),
					'description' => esc_html__('Choose icon alignment.', 'babystreet-plugin')
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Icon Style', 'babystreet-plugin'),
					'param_name' => 'icon_style',
					'value' => array(
						esc_html__('Circle', 'babystreet-plugin') => '',
						esc_html__('Square', 'babystreet-plugin') => 'babystreet-icon-box-square',
						esc_html__('Clean', 'babystreet-plugin') => 'babystreet-clean-icon'
					),
					'description' => esc_html__('Choose icon style.', 'babystreet-plugin')
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Appear Animation', 'babystreet-plugin'),
					'param_name' => 'appear_animation',
					'value' => array(
						esc_html__('none', 'babystreet-plugin') => '',
						esc_html__('From Left', 'babystreet-plugin') => 'babystreet-from-left',
						esc_html__('From Right', 'babystreet-plugin') => 'babystreet-from-right',
						esc_html__('From Bottom', 'babystreet-plugin') => 'babystreet-from-bottom',
						esc_html__('Fade', 'babystreet-plugin') => 'babystreet-fade'
					),
					'description' => esc_html__('Choose how the element will appear.', 'babystreet-plugin')
				),
				array(
					'type' => 'textarea_html',
					'holder' => 'div',
					'class' => '',
					'heading' => esc_html__('Text', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'content',
					'description' => esc_html__('Enter the text that will be used with the icon', 'babystreet-plugin'),
				),
			),
			'js_view' => 'VcIconElementView_Backend',
		));

		// Map babystreet_map shortcode
		vc_map(array(
			'name' => esc_html__('Map', 'babystreet-plugin'),
			'base' => 'babystreet_map',
			'icon' => $althem_icon,
			'description' => esc_html__('Map with location', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Location Title', 'babystreet-plugin'),
					'param_name' => 'location_title',
					'value' => '',
					'description' => esc_html__('Will appear when hover over the location.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Latitude', 'babystreet-plugin'),
					'param_name' => 'map_latitude',
					'value' => '',
					'description' => esc_html__('Enter location latitude.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Longitude', 'babystreet-plugin'),
					'param_name' => 'map_longitude',
					'value' => '',
					'description' => esc_html__('Enter location longitude.', 'babystreet-plugin') . '</br></br>' . sprintf(_x('Go to %s and get your location coordinates: </br>(e.g. Latitude: 40.588372 / Longitude: -74.240112)', 'theme-options', 'babystreet-plugin'), '<a href="https://www.latlong.net/" target="_blank">www.latlong.net</a>'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Map height', 'babystreet-plugin'),
					'param_name' => 'height',
					'value' => '400',
					'description' => esc_html__('Map height in px.', 'babystreet-plugin'),
				),
			)
		));
		// Map babystreet_pricing_table shortcode
		vc_map(array(
			'name' => esc_html__('Pricing Table', 'babystreet-plugin'),
			'base' => 'babystreet_pricing_table',
			'icon' => $althem_icon,
			'description' => esc_html__('Create pricing tables', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Title', 'babystreet-plugin'),
					'param_name' => 'title',
					'value' => '',
					'description' => esc_html__('Enter the table title.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Sub Title', 'babystreet-plugin'),
					'param_name' => 'subtitle',
					'value' => '',
					'description' => esc_html__('Enter sub title.', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Styled for Dark Background', 'babystreet-plugin'),
					'param_name' => 'styled_for_dark',
					'value' => array(esc_html__('Yes', 'babystreet-plugin') => 'yes')
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Price Bills', 'babystreet-plugin'),
					'param_name' => 'price',
					'value' => '',
					'description' => esc_html__('Enter the bills price for this package. e.g. 157.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Price Coins', 'babystreet-plugin'),
					'param_name' => 'price_coins',
					'value' => '',
					'description' => esc_html__('Enter the coins for the price. e.g. 49 , for a price of 157.49', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Currency Symbol', 'babystreet-plugin'),
					'param_name' => 'currency_symbol',
					'value' => '',
					'description' => esc_html__('Enter the currency symbol for the price. e.g. $.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Period', 'babystreet-plugin'),
					'param_name' => 'period',
					'value' => '',
					'description' => esc_html__('e.g. per month.', 'babystreet-plugin'),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__('Appear Animation', 'babystreet-plugin'),
					'param_name' => 'appear_animation',
					'value' => array(
						esc_html__('none', 'babystreet-plugin') => '',
						esc_html__('From Left', 'babystreet-plugin') => 'babystreet-from-left',
						esc_html__('From Right', 'babystreet-plugin') => 'babystreet-from-right',
						esc_html__('From Bottom', 'babystreet-plugin') => 'babystreet-from-bottom',
						esc_html__('Fade', 'babystreet-plugin') => 'babystreet-fade'
					),
					'description' => esc_html__('Choose how the element will appear.', 'babystreet-plugin')
				),
				array(
					'type' => 'textarea_html',
					'holder' => 'div',
					'class' => '',
					'heading' => esc_html__('Content', 'babystreet-plugin'),
					'value' => '',
					'param_name' => 'content',
					'description' => esc_html__('Enter the pricing table content', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Button Text', 'babystreet-plugin'),
					'param_name' => 'button_text',
					'value' => '',
					'description' => esc_html__('Enter text for the button.', 'babystreet-plugin'),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Link', 'babystreet-plugin'),
					'param_name' => 'link',
					'value' => '',
					'description' => esc_html__('Enter the URL for the button.', 'babystreet-plugin'),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Accent Color', 'babystreet-plugin'),
					'param_name' => 'accent_color',
					'value' => '',
					'description' => esc_html__('Choose accent color of the pricing table.', 'babystreet-plugin'),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Featured', 'babystreet-plugin'),
					'param_name' => 'featured',
					'value' => array(esc_html__('Mark as featured', 'babystreet-plugin') => 'yes')
				)
			),
			'js_view' => 'VcIconElementView_Backend',
		));
		// Map babystreet_contact_form shortcode
		vc_map(array(
			'name' => esc_html__('Contact Form', 'babystreet-plugin'),
			'base' => 'babystreet_contact_form',
			'icon' => $althem_icon,
			'description' => esc_html__('Configurable Contact Form', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Title', 'babystreet-plugin'),
					'param_name' => 'title',
					'value' => '',
					'description' => esc_html__('Enter contact form title.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Receiving Email Address', 'babystreet-plugin'),
					'param_name' => 'contact_mail_to',
					'value' => $current_user_email,
					'description' => esc_html__('Email address for receing the contact form email.', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Use Captcha', 'babystreet-plugin'),
					'param_name' => 'simple_captcha',
					'value' => array(esc_html__('Use simple captcha for the contact form', 'babystreet-plugin') => true),
				),
				array(
					'type' => 'checkbox',
					'heading' => esc_html__('Select Fields for the Contact Form', 'babystreet-plugin'),
					'param_name' => 'contact_form_fields',
					'value' => array(
						esc_html__('Name', 'babystreet-plugin') => 'name',
						esc_html__('E-Mail Address', 'babystreet-plugin') => 'email',
						esc_html__('Phone', 'babystreet-plugin') => 'phone',
						esc_html__('Street Address', 'babystreet-plugin') => 'address',
						esc_html__('Subject', 'babystreet-plugin') => 'subject',
					),
					'description' => esc_html__('Choose which fields to be displayed on the contact form. Selcted fields will also be required fields. The message textarea will be always displayed.', 'babystreet-plugin')
				)
			)
		));
		// Map babystreet_countdown shortcode
		vc_map(array(
			'name' => esc_html__('Countdown', 'babystreet-plugin'),
			'base' => 'babystreet_countdown',
			'icon' => $althem_icon,
			'description' => esc_html__('Customized Countdown', 'babystreet-plugin'),
			'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__('Expire Date', 'babystreet-plugin'),
					'param_name' => 'date',
					'value' => '',
					'description' => esc_html__('Enter the end date for the counter.', 'babystreet-plugin') . '<br/>' . esc_html__('Use following format YYYY/MM/DD HH:MM:SS, e.g. 2020/04/25 17:45:00', 'babystreet-plugin'),
					'admin_label' => true
				),
				array(
					'type' => 'dropdown',
					'param_name' => 'counter_size',
					'value' => array(
						esc_html__('Normal', 'babystreet-plugin') => '',
						esc_html__('Big', 'babystreet-plugin') => 'babystreet-counter-big',
					),
					'std' => '',
					'heading' => esc_html__('Size', 'babystreet-plugin'),
					'description' => esc_html__('Select counter size.', 'babystreet-plugin'),
				),
				array(
					'type' => 'colorpicker',
					'heading' => esc_html__('Color', 'babystreet-plugin'),
					'param_name' => 'color',
					'value' => '',
					'description' => esc_html__('Choose counter color.', 'babystreet-plugin'),
				)
			)
		));
// If WooCommerce is active
		if (defined('BABYSTREET_PLUGIN_IS_WOOCOMMERCE') && BABYSTREET_PLUGIN_IS_WOOCOMMERCE) {
			$order_by_values = array(
				'',
				esc_html__( 'Date', 'babystreet-plugin' ) => 'date',
				esc_html__( 'ID', 'babystreet-plugin' ) => 'ID',
				esc_html__( 'Author', 'babystreet-plugin' ) => 'author',
				esc_html__( 'Title', 'babystreet-plugin' ) => 'title',
				esc_html__( 'Modified', 'babystreet-plugin' ) => 'modified',
				esc_html__( 'Random', 'babystreet-plugin' ) => 'rand',
				esc_html__( 'Comment count', 'babystreet-plugin' ) => 'comment_count',
				esc_html__( 'Menu order', 'babystreet-plugin' ) => 'menu_order',
				esc_html__( 'Menu order and title', 'babystreet-plugin' ) => 'menu_order title',
				esc_html__( 'Include', 'babystreet-plugin' ) => 'include',
			);

			$order_way_values = array(
				'',
				esc_html__('Descending', 'babystreet-plugin') => 'DESC',
				esc_html__('Ascending', 'babystreet-plugin') => 'ASC',
			);

			$columns_values = array(2, 3, 4, 5, 6);

			// Map babystreet_woo_top_rated_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Top Rated Products Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_top_rated_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('List all products on sale in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Per page', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'per_page',
						'description' => esc_html__('How much items per page to show', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('How much columns grid', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'description' => sprintf(esc_html__('Select how to sort retrieved products. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
				)
			));

			// Map babystreet_woo_recent_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Recent Products Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_recent_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('Lists recent products in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Per page', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'per_page',
						'description' => esc_html__('The "per_page" shortcode determines how many products to show on the page', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('The columns attribute controls how many columns wide the products should be before wrapping.', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'description' => sprintf(esc_html__('Select how to sort retrieved products. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
				)
			));

			// Map babystreet_woo_featured_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Featured Products Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_featured_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('Display products set as featured in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Per page', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'per_page',
						'description' => esc_html__('The "per_page" shortcode determines how many products to show on the page', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('The columns attribute controls how many columns wide the products should be before wrapping.', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'description' => sprintf(esc_html__('Select how to sort retrieved products. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
				)
			));

			// Map babystreet_woo_sale_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Sale Products Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_sale_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('List all products on sale in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Per page', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'per_page',
						'description' => esc_html__('How much items per page to show', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('How much columns grid', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'description' => sprintf(esc_html__('Select how to sort retrieved products. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
				)
			));

			// Map babystreet_woo_best_selling_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Best Selling Products Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_best_selling_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('List best selling products in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Per page', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'per_page',
						'description' => esc_html__('How much items per page to show', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('How much columns grid', 'babystreet-plugin'),
					),
				)
			));

			// Map babystreet_woo_product_category_carousel shortcode
			vc_map(array(
				'name' => __( 'Product Category Carousel', 'babystreet-plugin' ),
				'base' => 'babystreet_woo_product_category_carousel',
				'icon' => $althem_icon,
				'category' => __( 'Babystreet Shortcodes', 'babystreet-plugin' ),
				'description' => __( 'Show products from category in carousel', 'babystreet-plugin' ),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Per page', 'babystreet-plugin' ),
						'value' => 12,
						'save_always' => true,
						'param_name' => 'per_page',
						'description' => __( 'How much items per page to show', 'babystreet-plugin' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Columns', 'babystreet-plugin' ),
						'value' => 4,
						'save_always' => true,
						'param_name' => 'columns',
						'description' => __( 'How much columns grid', 'babystreet-plugin' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Order by', 'babystreet-plugin' ),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'std' => 'menu_order title',
						// Default WC value
						'save_always' => true,
						'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'babystreet-plugin' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Sort order', 'babystreet-plugin' ),
						'param_name' => 'order',
						'value' => $order_way_values,
						'std' => 'ASC',
						// default WC value
						'save_always' => true,
						'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', 'babystreet-plugin' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
					),
					array(
						'type' => 'autocomplete',
						'heading' => esc_html__('Category', 'babystreet-plugin'),
						'param_name' => 'category',
						'save_always' => true,
						'settings' => array(
							'multiple' => false,
							'sortable' => false,
						),
						'description' => esc_html__('Product category lists', 'babystreet-plugin'),
					),
				),
			));

			// Map babystreet_woo_recent_viewed_products shortcode
			vc_map(array(
				'name' => esc_html__('Recently Viewed Products', 'babystreet-plugin'),
				'base' => 'babystreet_woo_recent_viewed_products',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('List recently viewed products', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Title', 'babystreet-plugin'),
						'value' => esc_html__('Recently viewed products', 'babystreet-plugin'),
						'param_name' => 'title',
						'description' => esc_html__('Title for the shortcode.', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Layout', 'babystreet-plugin'),
						'value' => array(
							esc_html__('Grid', 'babystreet-plugin') => 'grid',
							esc_html__('Carousel', 'babystreet-plugin') => 'carousel',
						),
						'description' => esc_html__('Choose between grid and carousel layout.', 'babystreet-plugin'),
						'param_name' => 'layout',
						'admin_label' => true
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => $columns_values,
						'param_name' => 'columns',
						'description' => esc_html__('How many products to be displayed on a row.', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Number of Products', 'babystreet-plugin'),
						'value' => 12,
						'param_name' => 'num_of_products',
						'description' => esc_html__('Number of products to show.', 'babystreet-plugin'),
						'admin_label' => true
					),
				)
			));

			// Map babystreet_woo_product_categories_carousel shortcode
			vc_map(array(
				'name' => esc_html__('Product Categories Carousel', 'babystreet-plugin'),
				'base' => 'babystreet_woo_product_categories_carousel',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('Display categories in carousel', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Number', 'babystreet-plugin'),
						'param_name' => 'number',
						'description' => esc_html__('The `number` field is used to display the number of products.', 'babystreet-plugin'),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'description' => sprintf(esc_html__('Select how to sort retrieved products. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Columns', 'babystreet-plugin'),
						'value' => 4,
						'param_name' => 'columns',
						'description' => esc_html__('How much columns grid', 'babystreet-plugin'),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Number', 'babystreet-plugin'),
						'param_name' => 'hide_empty',
						'description' => esc_html__('Hide empty', 'babystreet-plugin'),
					),
					array(
						'type' => 'autocomplete',
						'heading' => esc_html__('Categories', 'babystreet-plugin'),
						'param_name' => 'ids',
						'settings' => array(
							'multiple' => true,
							'sortable' => true,
						),
						'description' => esc_html__('List of product categories', 'babystreet-plugin'),
					),
				)
			));
			//Filters For autocomplete param:
			//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback

			add_filter('vc_autocomplete_babystreet_woo_product_categories_carousel_ids_callback', 'babystreet_productCategoryCategoryAutocompleteSuggester', 10, 1); // Get suggestion(find). Must return an array
			add_filter('vc_autocomplete_babystreet_woo_product_categories_carousel_ids_render', 'babystreet_productCategoryCategoryRenderByIdExact', 10, 1); // Render exact category by id. Must return an array (label,value)
			add_filter('vc_autocomplete_babystreet_woo_product_category_carousel_category_callback', 'babystreet_productCategoryCategoryAutocompleteSuggester', 10, 1); // Get suggestion(find). Must return an array
			add_filter('vc_autocomplete_babystreet_woo_product_category_carousel_category_render', 'babystreet_productCategoryCategoryRenderByIdExact', 10, 1); // Render exact category by id. Must return an array (label,value)
			// Map babystreet_woo_products_slider shortcode
			vc_map(array(
				'name' => esc_html__('Products Slider', 'babystreet-plugin'),
				'base' => 'babystreet_woo_products_slider',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('Display Products in slider', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order by', 'babystreet-plugin'),
						'param_name' => 'orderby',
						'value' => $order_by_values,
						'std' => 'title',
						'description' => sprintf(__('Select how to sort retrieved products. More at %s. Default by Title', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => $order_way_values,
						'description' => sprintf(__('Designates the ascending or descending order. More at %s. Default by ASC', 'babystreet-plugin'), '<a href="http://codex.wordpress.org/Class_Babystreetence/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
					),
					array(
						'type' => 'autocomplete',
						'heading' => esc_html__('Products', 'babystreet-plugin'),
						'param_name' => 'ids',
						'admin_label' => true,
						'settings' => array(
							'multiple' => true,
							'sortable' => true,
							'unique_values' => true,
							// In UI show results except selected. NB! You should manually check values in backend
						),
						'description' => esc_html__('Enter List of Products', 'babystreet-plugin'),
					),
					array(
						'type' => 'hidden',
						'param_name' => 'skus',
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__('Autoplay', 'babystreet-plugin'),
						'value' => array(esc_html__('On', 'babystreet-plugin') => 'yes'),
						'param_name' => 'autoplay',
						'std' => 'yes',
						'admin_label' => true
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Autoplay Timeout', 'babystreet-plugin'),
						'param_name' => 'timeout',
						'value' => '5',
						'description' => esc_html__('Autoplay interval timeout in seconds.', 'babystreet-plugin'),
					),
				)
			));

			// Add Elegant Icons Font
			$attributes_icon = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'icon_etline',
				'value' => 'icon-mobile', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'etline',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'type',
					'value' => 'etline',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			// Add Flaticon Icons Font
			$attributes_flaticon_icon = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'icon_flaticon',
				'value' => 'flaticon-3-standing-archives', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'flaticon',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'type',
					'value' => 'flaticon',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			$attributes_rest = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'icon_etline',
				'value' => 'icon-mobile', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'etline',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'icon_type',
					'value' => 'etline',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			$attributes_flaticon_rest = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'icon_flaticon',
				'value' => 'flaticon-3-standing-archives', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'flaticon',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'icon_type',
					'value' => 'flaticon',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			$attributes_i = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'i_icon_etline',
				'value' => 'icon-mobile', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'etline',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'i_type',
					'value' => 'etline',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			$attributes_i_flaticon = array(
				'type' => 'iconpicker',
				'heading' => esc_html__('Icon', 'babystreet-plugin'),
				'param_name' => 'i_icon_flaticon',
				'value' => 'flaticon-3-standing-archives', // default value to backend editor admin_label
				'settings' => array(
					'emptyIcon' => false,
					'type' => 'flaticon',
					'iconsPerPage' => 100,
					// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
				),
				'dependency' => array(
					'element' => 'i_type',
					'value' => 'flaticon',
				),
				'description' => esc_html__('Select icon from library.', 'babystreet-plugin'),
			);

			vc_add_param('vc_icon', $attributes_icon);
			vc_add_param('vc_icon', $attributes_flaticon_icon);
			vc_add_param('vc_message', $attributes_rest);
			vc_add_param('vc_message', $attributes_flaticon_rest);
			vc_add_param('babystreet_counter', $attributes_i);
			vc_add_param('babystreet_counter', $attributes_i_flaticon);

			//Filters For autocomplete param:
			//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback
			$WCvendor = new Vc_Vendor_Woocommerce();

			add_filter('vc_autocomplete_babystreet_woo_products_slider_ids_callback', array(&$WCvendor, 'productIdAutocompleteSuggester'), 10, 1); // Get suggestion(find). Must return an array
			add_filter('vc_autocomplete_babystreet_woo_products_slider_ids_render', array(&$WCvendor, 'productIdAutocompleteRender'), 10, 1); // Render exact product. Must return an array (label,value)
			//For param: ID default value filter
			add_filter('vc_form_fields_render_field_babystreet_woo_products_slider_ids_param_value', array(&$WCvendor, 'productsIdsDefaultValue'), 10, 4); // Defines default value for param if not provided. Takes from other param value.
		}

		// If WCMp is active
		if (defined('BABYSTREET_PLUGIN_IS_WC_MARKETPLACE') && BABYSTREET_PLUGIN_IS_WC_MARKETPLACE) {

			// Map babystreet_woo_top_rated_carousel shortcode
			vc_map(array(
				'name' => esc_html__('WCMp Vendors List', 'babystreet-plugin'),
				'base' => 'babystreet_wcmp_vendorslist',
				'icon' => $althem_icon,
				'category' => esc_html__('Babystreet Shortcodes', 'babystreet-plugin'),
				'description' => esc_html__('Displays registered vendors', 'babystreet-plugin'),
				'params' => array(
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order By', 'babystreet-plugin'),
						'value' => array(
							esc_html__('Date Registered', 'babystreet-plugin') => 'registered',
							esc_html__('Vendor Name', 'babystreet-plugin') => 'name',
							esc_html__('Product Category', 'babystreet-plugin') => 'category'
						),
						'param_name' => 'orderby',
						'description' => esc_html__('Sort vendors by chosen order parameter.', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__('Order Way', 'babystreet-plugin'),
						'param_name' => 'order',
						'value' => array(
							esc_html__('Ascending', 'babystreet-plugin') => 'ASC',
							esc_html__('Descending', 'babystreet-plugin') => 'DESC',
						),
						'description' => esc_html__('Designates the ascending or descending order.', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Number of Vendors Listed', 'babystreet-plugin'),
						'param_name' => 'limit',
						'value' => '',
						'description' => esc_html__('Enter the number of vendors to be displayed. NOTE: If leaved empty, all vendors will be listed.', 'babystreet-plugin'),
						'admin_label' => true
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__('Hide Sorting Options', 'babystreet-plugin'),
						'param_name' => 'hide_order_by',
						'value' => array(esc_html__('Hide "Sort" dropdown', 'babystreet-plugin') => 'yes'),
						'admin_label' => true
					),
				)
			));
		}

	}

}

add_action('vc_after_init', 'babystreet_add_etline_type'); /* Note: here we are using vc_after_init because WPBMap::GetParam and mutateParame are available only when default content elements are "mapped" into the system */
if (!function_exists('babystreet_add_etline_type')) {

	/**
	 * Add Elegant Icons Font option to the
	 * shortcode type parameters
	 */
	function babystreet_add_etline_type() {

		//Get current values stored in the type param in "Call to Action" element
		$param = WPBMap::getParam('vc_icon', 'type');
		//Append new value to the 'value' array
		$param['value'][esc_html__('Elegant Icons Font', 'babystreet-plugin')] = 'etline';
		$param['value'][esc_html__('Doodles Font', 'babystreet-plugin')] = 'flaticon';
		//Finally "mutate" param with new values
		vc_update_shortcode_param('vc_icon', $param);

		$param = WPBMap::getParam('vc_message', 'icon_type');
		$param['value'][esc_html__('Elegant Icons Font', 'babystreet-plugin')] = 'etline';
		$param['value'][esc_html__('Doodles Font', 'babystreet-plugin')] = 'flaticon';
		vc_update_shortcode_param('vc_message', $param);

		$param = WPBMap::getParam('babystreet_counter', 'i_type');
		$param['value'][esc_html__('Elegant Icons Font', 'babystreet-plugin')] = 'etline';
		$param['value'][esc_html__('Doodles Font', 'babystreet-plugin')] = 'flaticon';
		vc_update_shortcode_param('babystreet_counter', $param);
	}

}

// Add additional parameters on VC shortcodes
add_action('vc_before_init', 'babystreet_add_atts_vc_shortcodes');
if (!function_exists('babystreet_add_atts_vc_shortcodes')) {

	function babystreet_add_atts_vc_shortcodes() {

		$video_opacity_values = array('1' => '1');
		for ($j = 9; $j >= 1; $j--) {
			$video_opacity_values['0.' . $j] = '0.' . $j;
		}

		$video_background_attributes = array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__('YouTube video URL', 'babystreet-plugin'),
				'param_name' => 'video_bckgr_url',
				'value' => '',
				'description' => esc_html__('Paste the YouTube URL.', 'babystreet-plugin'),
				'group' => esc_html__('Babystreet Video Background', 'babystreet-plugin')
			),
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Video Opacity', 'babystreet-plugin'),
				'param_name' => 'video_opacity',
				'value' => $video_opacity_values,
				'description' => esc_html__('Set opacity fot the video.', 'babystreet-plugin'),
				'group' => esc_html__('Babystreet Video Background', 'babystreet-plugin')
			),
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Raster', 'babystreet-plugin'),
				'param_name' => 'video_raster',
				'value' => array(esc_html__('Enable Raster effect', 'babystreet-plugin') => 'yes'),
				'group' => esc_html__('Babystreet Video Background', 'babystreet-plugin')
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__('Start time', 'babystreet-plugin'),
				'param_name' => 'video_bckgr_start',
				'value' => '',
				'description' => esc_html__('Set the seconds the video should start at.', 'babystreet-plugin'),
				'group' => esc_html__('Babystreet Video Background', 'babystreet-plugin')
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__('End time', 'babystreet-plugin'),
				'param_name' => 'video_bckgr_end',
				'value' => '',
				'description' => esc_html__('Set the seconds the video should stop at.', 'babystreet-plugin'),
				'group' => esc_html__('Babystreet Video Background', 'babystreet-plugin')
			),
		);

		// Additional attributes for vc_row shortcode
		$attributes = array_merge($video_background_attributes, array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('General row alignment', 'babystreet-plugin'),
				'param_name' => 'general_row_align',
				'value' => array(
					esc_html__('Left', 'babystreet-plugin') => '',
					esc_html__('Right', 'babystreet-plugin') => 'babystreet-align-right',
					esc_html__('Center', 'babystreet-plugin') => 'babystreet-align-center'
				),
				'group' => esc_html__('Design Options', 'babystreet-plugin')
			),
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Allow content overflow', 'babystreet-plugin'),
				'param_name' => 'allow_overflow',
				'value' => array(esc_html__('Yes', 'babystreet-plugin') => 'yes'),
				'group' => esc_html__('Design Options', 'babystreet-plugin')
			),
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Fixed Background', 'babystreet-plugin'),
				'param_name' => 'fixed_background',
				'value' => array(esc_html__('Yes', 'babystreet-plugin') => 'yes'),
				'group' => esc_html__('Design Options', 'babystreet-plugin')
			),
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Weaves Effect', 'babystreet-plugin'),
				'param_name' => 'weaves_effect',
				'value' => array(esc_html__('Yes', 'babystreet-plugin') => 'yes'),
				'description' => esc_html__('Show moving waves effect at the row bottom.', 'babystreet-plugin'),
				'group' => esc_html__('Design Options', 'babystreet-plugin')
			),
		));
		// Add params to Row shortcode
		vc_add_params('vc_row', $attributes);

		// Add params to Inner Row shortcode
		$inner_row_attributes = array_merge($video_background_attributes, array(
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Weaves Effect', 'babystreet-plugin'),
				'param_name' => 'weaves_effect',
				'value' => array(esc_html__('Yes', 'babystreet-plugin') => 'yes'),
				'description' => esc_html__('Show moving waves effect at the row bottom.', 'babystreet-plugin'),
				'group' => esc_html__('Design Options', 'babystreet-plugin')
			)
		));
		vc_add_params('vc_row_inner', $inner_row_attributes);

		// Additional attributes for vc_progress_bar shortcode
		$attributes = array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Dysplay Style', 'babystreet-plugin'),
				'param_name' => 'display_style',
				'value' => array(
					esc_html__('Classic Style', 'babystreet-plugin') => '',
					esc_html__('Babystreet Style', 'babystreet-plugin') => 'babystreet-progress-bar'
				),
				'weight' => 1,
				'description' => esc_html__('Choose between the standard VC style and Babystreet style.', 'babystreet-plugin')
			)
		);
		vc_add_params('vc_progress_bar', $attributes);

		// Additional attributes for vc_custom_heading shortcode
		$attributes = array(
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Line Accent', 'babystreet-plugin'),
				'param_name' => 'line_accent',
				'description' => esc_html__('Append line accent to the text.', 'babystreet-plugin')
			),
			array(
				'type' => 'checkbox',
				'heading' => esc_html__('Special Font', 'babystreet-plugin'),
				'param_name' => 'special_font',
				'description' => esc_html__('Use special font for the heading.', 'babystreet-plugin')
			)
		);
		vc_add_params('vc_custom_heading', $attributes);
	}

}

// Hook to where classes are added in VC shortcodes (for all shortcodes)
if(defined('VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG')) {
	add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'babystreet_add_custom_classes_to_vc_shortcodes', 10, 3 );
}
if (!function_exists('babystreet_add_custom_classes_to_vc_shortcodes')) {

	function babystreet_add_custom_classes_to_vc_shortcodes( $classes, $shortcode_name, $attributes ) {
		if(is_array($attributes)) {
			if ( $shortcode_name === 'vc_custom_heading' ) {
				if(array_key_exists( 'line_accent', $attributes ) && $attributes['line_accent']) {
					$classes .= ' babystreet-line-accent-text';
				}
				if(array_key_exists( 'special_font', $attributes ) && $attributes['special_font']) {
					$classes .= ' special-font';
				}
			}
		}

		return $classes;
	}
}

// Autocomplete suggestor for babystreet_woo_product_categories_carousel
if (!function_exists('babystreet_productCategoryCategoryAutocompleteSuggester')) {

	function babystreet_productCategoryCategoryAutocompleteSuggester($query, $slug = false) {
		global $wpdb;

		$cat_id = (int) $query;
		$query = trim($query);
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare("SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'product_cat' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )", $cat_id > 0 ? $cat_id : - 1, stripslashes($query), stripslashes($query)), ARRAY_A);

		$result = array();
		if (is_array($post_meta_infos) && !empty($post_meta_infos)) {
			foreach ($post_meta_infos as $value) {
				$data = array();
				$data['value'] = $slug ? $value['slug'] : $value['id'];
				$data['label'] = esc_html__('Id', 'babystreet-plugin') . ': ' .
				                 $value['id'] .
				                 ( ( strlen($value['name']) > 0 ) ? ' - ' . esc_html__('Name', 'babystreet-plugin') . ': ' .
				                                                    $value['name'] : '' ) .
				                 ( ( strlen($value['slug']) > 0 ) ? ' - ' . esc_html__('Slug', 'babystreet-plugin') . ': ' .
				                                                    $value['slug'] : '' );
				$result[] = $data;
			}
		}

		return $result;
	}

}

// Render by ID for babystreet_woo_product_categories_carousel
if (!function_exists('babystreet_productCategoryCategoryRenderByIdExact')) {

	function babystreet_productCategoryCategoryRenderByIdExact($query) {
		global $wpdb;
		$query = $query['value'];
		$cat_id = (int) $query;
		$term = get_term($cat_id, 'product_cat');

		$term_slug = $term->slug;
		$term_title = $term->name;
		$term_id = $term->term_id;

		$term_slug_display = '';
		if (!empty($term_sku)) {
			$term_slug_display = ' - ' . esc_html__('Sku', 'babystreet-plugin') . ': ' . $term_slug;
		}

		$term_title_display = '';
		if (!empty($product_title)) {
			$term_title_display = ' - ' . esc_html__('Title', 'babystreet-plugin') . ': ' . $term_title;
		}

		$term_id_display = esc_html__('Id', 'babystreet-plugin') . ': ' . $term_id;

		$data = array();
		$data['value'] = $term_id;
		$data['label'] = $term_id_display . $term_title_display . $term_slug_display;

		return !empty($data) ? $data : false;
	}

}

if (!function_exists('babystreet_icon_element_fonts_enqueue')) {

	/**
	 * Enqueue icon element font
	 * @param $font
	 */
	function babystreet_icon_element_fonts_enqueue($font) {
		switch ($font) {
			case 'fontawesome':
				wp_enqueue_style('vc_font_awesome_5');
				break;
			case 'openiconic':
				wp_enqueue_style('vc_openiconic');
				break;
			case 'typicons':
				wp_enqueue_style('vc_typicons');
				break;
			case 'entypo':
				wp_enqueue_style('vc_entypo');
				break;
			case 'linecons':
				wp_enqueue_style('vc_linecons');
				break;
			default:
				do_action('vc_enqueue_font_icon_element', $font); // hook to custom do enqueue style
		}
	}

}
