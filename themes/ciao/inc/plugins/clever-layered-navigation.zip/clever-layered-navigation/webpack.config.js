const path = require('path');

module.exports = {
    mode: 'production',
    watch: true,
    watchOptions: {
        ignored: ['node_modules', 'assets/js/*.min.js']
    },
    entry: {
        frontend: "./assets/js/frontend.js"
    },
    output: {
        filename: '[name].min.js',
        path: path.resolve(__dirname, 'assets/js'),
    }
};
